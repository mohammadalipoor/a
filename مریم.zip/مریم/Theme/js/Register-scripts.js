﻿

    $(document).ready(function () {

        $('#idostan').change(function () {
            $("#LoadingImage").show();
            var valueselect = $('#idostan').val();

            $.get("../Theme/data/" + valueselect + ".txt", function (data, status) {
                var lines = data.split('\n');
                $("#idshahr").empty();
                var fop = $('<option></option>').attr("value", "0").text("انتخاب شهر");
                $("#idshahr").append(fop);
                for (var i = 0; i < lines.length; i++) {
                    $("#idshahr").append(lines[i]);
                }

                $("#LoadingImage").hide();
            });

        });
    });


    function testEmailAddress(emailToTest) {

        var atSymbol = emailToTest.indexOf("@@");
        if (atSymbol < 1) return false;


        var dot = emailToTest.indexOf(".");

        if (dot <= atSymbol + 2) return false;

        // check that the dot is not at the end
        if (dot === emailToTest.length - 1) return false;

        return true;
    }

function checkstep1()
{
    alertify.set({ labels: { ok: "تائید" } });
    // validate step 1
    if ($("#esm").val() == null || $("#esm").val() == "") {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }
        $("#desm").css("background-color", "#eeb9f5");
        element = document.getElementById("desm")
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("نام نوشته نشده است", function (e) {
            $("#desm").css("background-color", "#eeb9f5");
            element = document.getElementById("desm")
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    // var re = new RegExp("^[\u0600-\u06FF\s]+$");
    var re = new RegExp("^[\u0600-\u06FF ]+$");//
    if (re.test($("#esm").val())) {
        isvalid = true;
    } else {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }
        $("#desm").css("background-color", "#eeb9f5");
        element = document.getElementById("desm");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("نام باید فارسی بدون عدد باشد", function (e) {
            element = document.getElementById("desm");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#famili").val() == null || $("#famili").val() == "") {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }
        $("#dfamili").css("background-color", "#eeb9f5");
        element = document.getElementById("dfamili");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("نام خانوادگی نوشته نشده است", function (e) {
            element = document.getElementById("dfamili");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }

    if ($("#jens").val() == "select") {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }

        $("#djens").css("background-color", "#eeb9f5");
        element = document.getElementById("djens");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("جنسیت انتخاب نشده است", function (e) {
            element = document.getElementById("djens");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#idostan").val() == 0) {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }

        $("#didostan").css("background-color", "#eeb9f5");
        element = document.getElementById("didostan");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("استان انتخاب نشده است", function (e) {
            element = document.getElementById("didostan");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#idshahr").val() == 0) {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }
        $("#didshahr").css("background-color", "#eeb9f5");
        element = document.getElementById("didshahr")
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("شهر انتخاب نشده است", function (e) {
            element = document.getElementById("didshahr");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#id_tahsilat").val() == 0) {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }
        $("#did_tahsilat").css("background-color", "#eeb9f5");
        element = document.getElementById("desm");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("تحصیلات انتخاب نشده است", function (e) {
            element = document.getElementById("desm");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#id_eshteghal").val() == 0) {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }

        $("#did_eshteghal").css("background-color", "#eeb9f5");
        element = document.getElementById("did_eshteghal");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("وضعیت اشتغال انتخاب نشده است", function (e) {
            element = document.getElementById("did_eshteghal");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#id_daramad_kh").val() == 0) {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }

        $("#did_daramad_kh").css("background-color", "#eeb9f5");
        element = document.getElementById("did_daramad_kh");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("میزان درآمد خانواده انتخاب نشده است", function (e) {
            element = document.getElementById("did_daramad_kh");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#id_daramad_shoma").val() == 0) {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }

        $("#did_daramad_shoma").css("background-color", "#eeb9f5");
        element = document.getElementById("did_daramad_shoma");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("میزان درآمد شما انتخاب نشده است", function (e) {
            element = document.getElementById("did_daramad_shoma");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#trooz").val() == 0 || $("#mah").val() == 0 || $("#tsal").val() == 0) {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }

        $("#dtavalod").css("background-color", "#eeb9f5");
        element = document.getElementById("dtavalod");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("تاریخ تولد به درستی انتخاب نشده است", function (e) {
            element = document.getElementById("dtavalod");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }

    if ($("#id_vaz_ezdevaj").val() == 0) {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }

        $("#did_vaz_ezdevaj").css("background-color", "#eeb9f5");
        element = document.getElementById("did_vaz_ezdevaj");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("وضعیت ازدواج انتخاب نشده است", function (e) {
            element = document.getElementById("did_vaz_ezdevaj");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#id_vaz_hejab").val() == 0) {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }
        $("#did_vaz_hejab").css("background-color", "#eeb9f5");
        element = document.getElementById("did_vaz_hejab");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("وضعیت پوشش انتخاب نشده است", function (e) {
            element = document.getElementById("did_vaz_hejab");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#reshte").val() == null || $("#reshte").val() == "") {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }
        $("#dreshte").css("background-color", "#eeb9f5");
        element = document.getElementById("dreshte");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("رشته تحصیلی نوشته نشده است", function (e) {
            element = document.getElementById("dreshte");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#shoghl").val() == null || $("#shoghl").val() == "") {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }
        $("#dshoghl").css("background-color", "#eeb9f5");
        element = document.getElementById("dshoghl");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("شغل نوشته نشده است", function (e) {
            element = document.getElementById("dshoghl");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }

    if ($("#id_vaz_maskan").val() == 0) {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }
        $("#did_vaz_maskan").css("background-color", "#eeb9f5");
        element = document.getElementById("did_vaz_maskan");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("وضعیت مسکن انتخاب نشده است", function (e) {
            element = document.getElementById("did_vaz_maskan");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#id_vaz_mashin").val() == 0) {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }
        $("#did_vaz_mashin").css("background-color", "#eeb9f5");
        element = document.getElementById("did_vaz_mashin");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("وضعیت اتومبیل انتخاب نشده است", function (e) {
            element = document.getElementById("did_vaz_mashin");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }

    if ($("#tedad_farzandan").val().toString() == "select") {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }
        if ($("#id_vaz_mashin").val() == 0) {
            if ($("#collapse1").hasClass("in") == false) {
                $("#ap1").click();
            }
            $("#dtedad_farzandan").css("background-color", "#eeb9f5");
            element = document.getElementById("dtedad_farzandan");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            alertify.alert("تعداد فرزندان انتخاب نشده است", function (e) {
                element = document.getElementById("dtedad_farzandan");
                alignWithTop = true;
                element.scrollIntoView(alignWithTop);
                return;
            });
            return;
        }
        return;
    }
    if ($("#sen_farzande_bozorg").val().toString() == "select") {
        if ($("#collapse1").hasClass("in") == false) {
            $("#ap1").click();
        }
        $("#dsen_farzande_bozorg").css("background-color", "#eeb9f5");
        element = document.getElementById("dsen_farzande_bozorg");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("سن بزرگترین فرزند انتخاب نشده است", function (e) {
            element = document.getElementById("dsen_farzande_bozorg");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    $("#p1").removeClass("panel-info").addClass("panel-success");
    $("#ap2").attr("data-toggle", "collapse");
    $("#ap2").click();

}

function checkstep2()
{

    alertify.set({ labels: { ok: "تائید" } });
    if ($("#ghad").val() == 0) {
        if ($("#collapse2").hasClass("in") == false) {
            $("#ap2").click();
        }
        $("#dghad").css("background-color", "#eeb9f5");
        element = document.getElementById("dghad");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("قد انتخاب نشده است", function (e) {
            element = document.getElementById("dghad");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#vazn").val() == 0) {
        if ($("#collapse2").hasClass("in") == false) {
            $("#ap2").click();
        }
        $("#dvazn").css("background-color", "#eeb9f5");
        element = document.getElementById("dvazn");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("وزن انتخاب نشده است", function (e) {
            element = document.getElementById("dvazn");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#id_range_post").val() == 0) {
        if ($("#collapse2").hasClass("in") == false) {
            $("#ap2").click();
        }
        $("#did_range_post").css("background-color", "#eeb9f5");
        element = document.getElementById("did_range_post");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("رنگ پوست انتخاب نشده است", function (e) {
            element = document.getElementById("did_range_post");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#id_din_o_etegadat").val() == 0) {
        if ($("#collapse2").hasClass("in") == false) {
            $("#ap2").click();
        }
        $("#did_din_o_etegadat").css("background-color", "#eeb9f5");
        element = document.getElementById("did_din_o_etegadat");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("دین و مذهب انتخاب نشده است", function (e) {
            element = document.getElementById("did_din_o_etegadat");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#id_mizan_etegadat").val() == 0) {
        if ($("#collapse2").hasClass("in") == false) {
            $("#ap2").click();
        }

        $("#did_mizan_etegadat").css("background-color", "#eeb9f5");
        element = document.getElementById("did_mizan_etegadat");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("میزان اعتقادات انتخاب نشده است", function (e) {
            element = document.getElementById("did_mizan_etegadat");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#id_meyar_ezdevaj_list").val() == 0) {
        if ($("#collapse2").hasClass("in") == false) {
            $("#ap2").click();
        }

        $("#did_meyar_ezdevaj_list").css("background-color", "#eeb9f5");
        element = document.getElementById("did_meyar_ezdevaj_list");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("معیار ازدواج انتخاب نشده است", function (e) {
            element = document.getElementById("did_meyar_ezdevaj_list");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }

    if ($("#zibayi").val() == 0) {
        if ($("#collapse2").hasClass("in") == false) {
            $("#ap2").click();
        }

        $("#dzibayi").css("background-color", "#eeb9f5");
        element = document.getElementById("dzibayi");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("زیبایی انتخاب نشده است", function (e) {
            element = document.getElementById("dzibayi");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#tip").val() == 0) {
        if ($("#collapse2").hasClass("in") == false) {
            $("#ap2").click();
        }

        $("#dtip").css("background-color", "#eeb9f5");
        element = document.getElementById("dtip");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("تیپ انتخاب نشده است", function (e) {
            element = document.getElementById("dtip");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#id_shiveye_zendegi").val() == 0) {
        if ($("#collapse2").hasClass("in") == false) {
            $("#ap2").click();
        }

        $("#did_shiveye_zendegi").css("background-color", "#eeb9f5");
        element = document.getElementById("did_shiveye_zendegi");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("شیوه زندگی انتخاب نشده است", function (e) {
            element = document.getElementById("did_shiveye_zendegi");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }

    if ($("#sigar").val().toString() == "select") {
        if ($("#collapse2").hasClass("in") == false) {
            $("#ap2").click();
        }

        $("#dsigar").css("background-color", "#eeb9f5");
        element = document.getElementById("dsigar");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("ایتم سیگار انتخاب نشده است", function (e) {
            element = document.getElementById("dsigar");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#alkol").val().toString() == "select") {
        if ($("#collapse2").hasClass("in") == false) {
            $("#ap2").click();
        }

        $("#dalkol").css("background-color", "#eeb9f5");
        element = document.getElementById("dalkol");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("ایتم الکل انتخاب نشده است", function (e) {
            element = document.getElementById("dalkol");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }

    if ($("#id_mehriyeh").val() == 0) {
        if ($("#collapse2").hasClass("in") == false) {
            $("#ap2").click();
        }

        $("#did_mehriyeh").css("background-color", "#eeb9f5");
        element = document.getElementById("did_mehriyeh");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("میزان مهریه انتخاب نشده است", function (e) {
            element = document.getElementById("did_mehriyeh");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }

    if ($("#id_gomiyat").val() == 0) {
        if ($("#collapse2").hasClass("in") == false) {
            $("#ap2").click();
        }

        $("#did_gomiyat").css("background-color", "#eeb9f5");
        element = document.getElementById("did_gomiyat");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("قومیت من انتخاب نشده است", function (e) {
            element = document.getElementById("did_gomiyat");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }

    if ($("#tedad_baradar").val().toString() == "select") {
        if ($("#collapse2").hasClass("in") == false) {
            $("#ap2").click();
        }

        $("#dtedad_baradar").css("background-color", "#eeb9f5");
        element = document.getElementById("dtedad_baradar");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("تعداد برادر انتخاب نشده است", function (e) {
            element = document.getElementById("dtedad_baradar");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#tedade_khahar").val().toString() == "select") {
        if ($("#collapse2").hasClass("in") == false) {
            $("#ap2").click();
        }

        $("#dtedade_khahar").css("background-color", "#eeb9f5");
        element = document.getElementById("dtedade_khahar");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("تعداد خواهر انتخاب نشده است", function (e) {
            element = document.getElementById("dtedade_khahar");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    $("#p2").removeClass("panel-info").addClass("panel-success");
    $("#ap3").attr("data-toggle", "collapse");
    $("#ap3").click();

}

function checkstep3() {

    alertify.set({ labels: { ok: "تائید" } });
    if ($("#id_vaz_salamat").val() == 0) {
        if ($("#collapse3").hasClass("in") == false) {
            $("#ap3").click();
        }

        $("#did_vaz_salamat").css("background-color", "#eeb9f5");
        element = document.getElementById("did_vaz_salamat");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("وضعیت سلامت انتخاب نشده است", function (e) {
            element = document.getElementById("did_vaz_salamat");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if (($("#id_vaz_salamat").val() == 2 || $("#id_vaz_salamat").val() == 3) && ($("#salamat_tozih").val() == null || $("#salamat_tozih").val() == "")) {
        if ($("#collapse3").hasClass("in") == false) {
            $("#ap3").click();
        }
        $("#did_vaz_salamat").css("background-color", "#eeb9f5");
        element = document.getElementById("did_vaz_salamat");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("لطفا توضیح مختصری درباره وضعیت سلامت خود بنویسید", function (e) {
            element = document.getElementById("did_vaz_salamat");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }

    if ($("#man_chenin_hastam").val() == null || $("#man_chenin_hastam").val() == "") {
        if ($("#collapse3").hasClass("in") == false) {
            $("#ap3").click();
        }

        $("#dman_chenin_hastam").css("background-color", "#eeb9f5");
        element = document.getElementById("dman_chenin_hastam");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("توضیحی در رابطه با من چنین هستم بدهید", function (e) {
            element = document.getElementById("dman_chenin_hastam");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }

    if ($("#man_chenin_hastam").val().length > 3950) {
        if ($("#collapse3").hasClass("in") == false) {
            $("#ap3").click();
        }

        $("#dman_chenin_hastam").css("background-color", "#eeb9f5");
        element = document.getElementById("dman_chenin_hastam");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("توضیحات من چنین هستم از حد مجاز بیشتر است", function (e) {
            element = document.getElementById("dman_chenin_hastam");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#hamsaram_chenin_bashad").val() == null || $("#hamsaram_chenin_bashad").val() == "") {
        if ($("#collapse3").hasClass("in") == false) {
            $("#ap3").click();
        }

        $("#dhamsaram_chenin_bashad").css("background-color", "#eeb9f5");
        element = document.getElementById("dhamsaram_chenin_bashad");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("توضیحی در رابطه با همسرم چنین باشد بدهید", function (e) {
            element = document.getElementById("dhamsaram_chenin_bashad");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#hamsaram_chenin_bashad").val().length > 3950) {
        if ($("#collapse3").hasClass("in") == false) {
            $("#ap3").click();
        }

        $("#dhamsaram_chenin_bashad").css("background-color", "#eeb9f5");
        element = document.getElementById("dhamsaram_chenin_bashad");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("توضیحات همسرم چنین باشد از حد مجاز بیشتر است", function (e) {
            element = document.getElementById("dhamsaram_chenin_bashad");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    $("#p3").removeClass("panel-info").addClass("panel-success");
    $("#ap4").attr("data-toggle", "collapse");
    $("#ap4").click();
    var myVar;
    myVar=setTimeout(function () {
        $('html,body').animate({
            scrollTop: $("#ap4").offset().top
        }, 100);
        clearTimeout(myVar);
    }, 500);
}

function checkstep4(){
    alertify.set({ labels: { ok: "تائید" } });

    if ($("#mojarad:checked").length == 0 && $("#talag_gerefteh:checked").length == 0 && $("#hamsar_fotshode:checked").length == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
      
        $("#c1").css("background-color", "#eeb9f5");
        element = document.getElementById("dvazeezdevaj");
        element.click();
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("حداقل یک مورد از وضعیت ازدواج همسر انتخاب شود", function (e) {
            element = document.getElementById("dvazeezdevaj");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#fars:checked").length == 0 && $("#turk:checked").length == 0 && $("#kord:checked").length == 0 && $("#lor:checked").length == 0 && $("#baloch:checked").length == 0 &&
        $("#mazandarani:checked").length == 0 && $("#gilaki:checked").length == 0 && $("#arab:checked").length == 0 && $("#sayereagvam:checked").length == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }

        $("#c2").css("background-color", "#eeb9f5");
        element = document.getElementById("dgomiyat");
        element.click();
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("حداقل یک مورد از قومیت همسر انتخاب شود", function (e) {
            element = document.getElementById("dgomiyat");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#hamshahri:checked").length == 0 && $("#hamostani:checked").length == 0 && $("#hamvatan:checked").length == 0 && $("#kharej_keshvar:checked").length == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }

        $("#c22").css("background-color", "#eeb9f5");
        element = document.getElementById("dmahalezendegi");
        element.click();
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("حداقل یک مورد از محل زندگی همسر انتخاب شود", function (e) {
            element = document.getElementById("dmahalezendegi");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#bikar:checked").length == 0 && $("#shaghel:checked").length == 0 && $("#daneshjo:checked").length == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
  
        $("#c3").css("background-color", "#eeb9f5");
        element = document.getElementById("deshteghal");
        element.click();
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("حداقل یک مورد از وضعیت شغل همسر انتخاب شود", function (e) {
            element = document.getElementById("deshteghal");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#sefid:checked").length == 0 && $("#sabze_roshan:checked").length == 0 && $("#sabze_tire:checked").length == 0 && $("#siyah:checked").length == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
    
        $("#c4").css("background-color", "#eeb9f5");
        element = document.getElementById("drangepost");
        element.click();
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("حداقل یک مورد از رنگ پوست همسر انتخاب شود", function (e) {
            element = document.getElementById("drangepost");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#maskan_yes:checked").length == 0 && $("#maskan_no:checked").length == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }

        $("#c5").css("background-color", "#eeb9f5");
        element = document.getElementById("dvazemaskan");
        element.click();
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("حداقل یک مورد از وضعیت مسکن همسر انتخاب شود", function (e) {
            element = document.getElementById("dvazemaskan");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#mashin_yes:checked").length == 0 && $("#mashin_no:checked").length == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
                   
        $("#c6").css("background-color", "#eeb9f5");
        element = document.getElementById("dvazemashin");
        element.click();
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("حداقل یک مورد از وضعیت ماشین همسر انتخاب شود", function (e) {
            element = document.getElementById("dvazemashin");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#salem:checked").length == 0 && $("#bimari_khas:checked").length == 0 && $("#nagse_ozv:checked").length == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }

        $("#c7").css("background-color", "#eeb9f5");
        element = document.getElementById("dvazesalamat");
        element.click();
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("حداقل یک مورد از وضعیت سلامتی همسر انتخاب شود", function (e) {
            element = document.getElementById("dvazesalamat");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#mazhabi_mogayad:checked").length == 0 && $("#mazhabi_mamoli:checked").length == 0 && $("#geyre_mazhabi:checked").length == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
       
        $("#c8").css("background-color", "#eeb9f5");
        element = document.getElementById("detegadat");
        element.click();
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("حداقل یک مورد از وضعیت اعتقادات همسر انتخاب شود", function (e) {
            element = document.getElementById("detegadat");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#farzand_yes:checked").length == 0 && $("#farzand_no:checked").length == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
         
        $("#c9").css("background-color", "#eeb9f5");
        element = document.getElementById("dfarzand");
        element.click();
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("حداقل یک مورد از وضعیت فرزند همسر انتخاب شود", function (e) {
            element = document.getElementById("dfarzand");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#etahsil_yes:checked").length == 0 && $("#etahsil_no:checked").length == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
       
        $("#c10").css("background-color", "#eeb9f5");
        element = document.getElementById("dedametahsil");
        element.click();
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("حداقل یک مورد از وضعیت ادامه تحصیل همسر انتخاب شود", function (e) {
            element = document.getElementById("dedametahsil");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    //
    if ($("#senaz").val() == 0 || $("#senta").val() == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
      
        $("#dsenaz").css("background-color", "#eeb9f5");
        element = document.getElementById("dsenaz");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("محدوده سن همسر انتخاب نشده است", function (e) {
            element = document.getElementById("dsenaz");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }

    if ($("#ghadaz").val() == 0 || $("#ghadta").val() == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
                      
        $("#dghadaz").css("background-color", "#eeb9f5");
        element = document.getElementById("dghadaz");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("محدوده قد همسر انتخاب نشده است", function (e) {
            element = document.getElementById("dghadaz");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#vaznaz").val() == 0 || $("#vaznta").val() == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
        $("#dvaznaz").css("background-color", "#eeb9f5");
        element = document.getElementById("dvaznaz");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("محدوده وزن همسر انتخاب نشده است", function (e) {
            element = document.getElementById("dvaznaz");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#tahsilat_az").val() == 0 || $("#tahsilat_ta").val() == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
 
        $("#dtahsilat_az").css("background-color", "#eeb9f5");
        element = document.getElementById("dtahsilat_az");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("محدوده تحصیلات همسر انتخاب نشده است", function (e) {
            element = document.getElementById("dtahsilat_az");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#daramad_kh_az").val() == 0 || $("#daramad_kh_ta").val() == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
      
        $("#ddaramad_kh_az").css("background-color", "#eeb9f5");
        element = document.getElementById("ddaramad_kh_az");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("محدوده درآمد خانواده همسر انتخاب نشده است", function (e) {
            element = document.getElementById("ddaramad_kh_az");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#daramad_hamsar_az").val() == 0 || $("#daramad_hamsar_ta").val() == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
          
        $("#ddaramad_hamsar_az").css("background-color", "#eeb9f5");
        element = document.getElementById("ddaramad_hamsar_az");
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("محدوده درآمد همسر انتخاب نشده است", function (e) {
            element = document.getElementById("ddaramad_hamsar_az");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    //
    if ($("#chadori:checked").length == 0 && $("#mamoli:checked").length == 0 && $("#sport:checked").length == 0 && $("#fashion:checked").length == 0) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
            
        $("#a1").css("background-color", "#eeb9f5");
        element = document.getElementById("dvazeposhesh");
        element.click();
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("حداقل یک مورد از وضعیت پوشش همسر انتخاب شود", function (e) {
            element = document.getElementById("dvazeposhesh");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#sigar_yes:checked").length == 0 && $("#sigar_no:checked").length == 0 ) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
               
        $("#a2").css("background-color", "#eeb9f5");
        element = document.getElementById("dvazesigar");
        element.click();
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("حداقل یک مورد از وضعیت مصرف سیگار همسر انتخاب شود", function (e) {
            element = document.getElementById("dvazesigar");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    if ($("#alkol_yes:checked").length == 0 && $("#alkol_no:checked").length == 0 ) {
        if ($("#collapse4").hasClass("in") == false) {
            $("#ap4").click();
        }
        $("#a3").css("background-color", "#eeb9f5");
        element = document.getElementById("dvazealkol");
        element.click();
        alignWithTop = true;
        element.scrollIntoView(alignWithTop);
        alertify.alert("حداقل یک مورد از وضعیت مصرف الکل همسر انتخاب شود", function (e) {
            element = document.getElementById("dvazealkol");
            alignWithTop = true;
            element.scrollIntoView(alignWithTop);
            return;
        });
        return;
    }
    $("#p4").removeClass("panel-info").addClass("panel-success");
    $("#ap5").attr("data-toggle", "collapse");
    $("#ap5").click();

}

function checkstep5()
{
    alertify.set({ labels: { ok: "تائید" } });

    if ($("#mobile").val() == null || $("#mobile").val() == "") {
        if ($("#collapse5").hasClass("in") == false) {
            $("#ap5").click();
        }
        alertify.alert("شماره موبایل وارد نشده است. شماره موبایل شما نمایش داده نخواهد شد");
        return;
    }
    var mm = new RegExp("^[\u06F0-\u06F90-9]+$");
    if (mm.test($("#mobile").val())) {
        isvalid = true;
    } else {
        if ($("#collapse5").hasClass("in") == false) {
            $("#ap5").click();
        }
        alertify.alert("شماره موبایل فقط باید عدد باشد");
        return;
    }

    if ($("#email").val() == null || $("#email").val() == "") {
        if ($("#collapse5").hasClass("in") == false) {
            $("#ap5").click();
        }
        alertify.alert("نام کاربری نمی تواند خالی باشد");
        return;
    }

    if ($("#password").val() == null || $("#password").val() == "") {
        if ($("#collapse5").hasClass("in") == false) {
            $("#ap5").click();
        }
        alertify.alert("رمز وارد نشده است");
        return;
    }
    var rp = new RegExp("^[\u0600-\u06FF]+$");
    if (rp.test($("#password").val())) {
        if ($("#collapse5").hasClass("in") == false) {
            $("#ap5").click();
        }
        alertify.alert("رمز عبور به صورت فارسی قابل قبول نیست");
        return;

    }
    if ($("#password").val().toString().length < 6) {
        if ($("#collapse5").hasClass("in") == false) {
            $("#ap5").click();
        }
        alertify.alert("پسورد حداقل باید شش کاراکتر باشد");
        return;
    }
    if ($("#password").val() != $("#repass").val()) {
        if ($("#collapse5").hasClass("in") == false) {
            $("#ap5").click();
        }
        alertify.alert("تکرار پسورد مطابقت ندارد");
        return;
    }
    $("#p5").removeClass("panel-info").addClass("panel-success");
    CheckExistUser();
}


function CheckExistUser() {

    var mm = $("#mobile").val();
    var ee = $("#email").val();

    $.ajax({
        type: "Post",
        url: "CheckExistUser",
        data: "mobile="+mm+"&email="+ee,
        contenttype: "application/text;charset=utf-8",
        datatype: "text",
        success: function (data) {

            if (data==1) {
                alertify.alert("شماره موبایل شما قبلا ثبت نام شده است");
                return;
            }
            if (data == 2) {
                alertify.alert("نام کاربری شما قبلا ثبت نام شده است");
                return;
            }
            if (data == 3) {
                alertify.alert("شماره موبایل و نام کاربری شما قبلا ثبت نام شده است");
                return;
            }
            if (data == 0) {
                $("#btnregister").click();
            }


        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    })
}

$(function () {
    $("#esm, #famili,#reshte,#shoghl,#man_chenin_hastam,#hamsaram_chenin_bashad,#salamat_tozih").farsiInput();
});

$("#collapse2").on('shown.bs.collapse', function (e) {
    var $panel = $(this).closest('.panel');
    $('html,body').animate({
        scrollTop: $panel.offset().top
    }, 100);
});
$("#collapse3").on('shown.bs.collapse', function (e) {
    var $panel = $(this).closest('.panel');
    $('html,body').animate({
        scrollTop: $panel.offset().top
    }, 100);
});
$("#collapse5").on('shown.bs.collapse', function (e) {
    var $panel = $(this).closest('.panel');
    $('html,body').animate({
        scrollTop: $panel.offset().top
    }, 100);
});
